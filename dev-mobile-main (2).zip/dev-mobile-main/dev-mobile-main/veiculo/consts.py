# -*- coding: utf-8 -*-

OPCOES_MARCAS = (
    (1, u'AUDI'),
    (2, u'BMW'),
    (3, u'CHEVROLET - GM'),
    (4, u'FERRARI'),
    (5, u'FIAT'),
    (7, u'FORD'),
    (8, u'HONDA'),
    (9, u'HYUNDAI'),
    (10, u'VOLKSWAGEN')
)

OPCOES_CORES = (
    (1, u'BRANCO'),
    (2, u'AMARELO'),
    (3, u'AZUL'),
    (4, u'PRATA'),
    (5, u'PRETO'),
    (6, u'VERMELHO')
)

OPCOES_COMBUSTIVEIS = (
    (1, u'ETANOL'),
    (2, u'DIESEL'),
    (3, u'FLEX'),
    (4, u'GASOLINA')
)